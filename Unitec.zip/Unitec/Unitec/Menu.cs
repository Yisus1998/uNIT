﻿using Common.Cache;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Unitec.Admin;
using Unitec.Carga;
using Unitec.Estacionamiento;

namespace Unitec
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
            miniz.Visible = false;

            if (UserLoginCache.Position != "Administrador")
            {
                iconButton4.Visible = false;
                //iconButton5.Visible = false;
                iconButton6.Visible = false;
               // iconButton1.Visible = false;
            }

            if (UserLoginCache.Position == "Administrador")
            {
                //iconButton4.Visible = false;
                iconButton5.Visible = false;
               // iconButton6.Visible = false;
                iconButton1.Visible = false;
                iconButton2.Visible = false;
                iconButton3.Visible = false;

            }

        }


        private void AbrirFormEnPanel(object Formhijo)
        {
            if (this.panel4.Controls.Count > 0)
                this.panel4.Controls.RemoveAt(0);
            Form fh = Formhijo as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panel4.Controls.Add(fh);
            this.panel4.Tag = fh;
            fh.Show();
        }


        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void Menu_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        private void LoadUserData()
        {
            label3.Text = UserLoginCache.LoginName;
            lblusuario.Text = UserLoginCache.Position;
            // lblcorreo.Text = UserLoginCache.Email;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {

            lblhora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void miniz_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            miniz.Visible = false;
            maximize.Visible = true;
        }

        private void maximize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            miniz.Visible = true;
            maximize.Visible = false;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            AbrirFormEnPanel(new DataDash());
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            AbrirFormEnPanel(new Persona());
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void Menu_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            AbrirFormEnPanel(new Entrada());
        }

        private void lblFecha_Click(object sender, EventArgs e)
        {

        }

        private void iconButton7_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {
            SalidaSistema log = new SalidaSistema();
            log.Show();
            this.Close();
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
         
            AbrirFormEnPanel(new Estacionamineto());
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            AbrirFormEnPanel(new Salida());
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblusuario_Click(object sender, EventArgs e)
        {

        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            AbrirFormEnPanel(new CRUD());
        }
    }
}
