﻿using Common.Cache;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Unitec.Admin;
using Unitec.Carga;

namespace Unitec
{
    public partial class Menu_Esta : Form
    {
        public Menu_Esta()
        {
            InitializeComponent();
        }
        private void LoadUserData()
        {
            label3.Text = UserLoginCache.LoginName;
            lblusuario.Text = UserLoginCache.Position;
            // lblcorreo.Text = UserLoginCache.Email;
        }

        private void AbrirFormEnPanel(object Formhijo)
        {
            if (this.panel4.Controls.Count > 0)
                this.panel4.Controls.RemoveAt(0);
            Form fh = Formhijo as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panel4.Controls.Add(fh);
            this.panel4.Tag = fh;
            fh.Show();
        }


        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void maximize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            miniz.Visible = true;
            maximize.Visible = false;
        }

        private void Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void miniz_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            miniz.Visible = false;
            maximize.Visible = true;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Menu_Esta_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblhora_Click(object sender, EventArgs e)
        {

        }

        private void lblFecha_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblhora.Text = DateTime.Now.ToString("hh:mm:ss ");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void lblusuario_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {
            SalidaSistema log = new SalidaSistema();
            log.Show();
            this.Close();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            AbrirFormEnPanel(new CRUD());
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
