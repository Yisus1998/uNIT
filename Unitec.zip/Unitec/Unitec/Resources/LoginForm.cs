﻿using Dominio;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Unitec.Carga;


namespace Unitec
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            txtuser.Focus();
        }


        #region Drag Form/ Mover Arrastrar Formulario
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        #endregion


        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void txtuser_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtuser.Text != "" && txtuser.TextLength > 3)
            {
                if (txtpass.Text != "")
                {
                    UserModel user = new UserModel();
                    var validLogin = user.LoginUser(txtuser.Text, txtpass.Text);
                    if (validLogin == true)
                    {
                        Cargar mainMenu = new Cargar();
                        mainMenu.Show();
                        Hide();
                    }
                    else
                    {
                        msgError("Nombre de usuario o contraseña incorrectos");

                    }
                }
                else msgError("Ingresa tu Contraseña.");
            }
            else msgError("Porfavor ingresa tu usuario.");
        }
        private void msgError(string msg)
        {
            label3.Text = "    " + msg;
            label3.Visible = true;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void txtpass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {

                if (txtuser.Text != "" && txtuser.TextLength > 2)
                {
                    if (txtpass.Text != "")
                    {
                        UserModel user = new UserModel();
                        var validLogin = user.LoginUser(txtuser.Text, txtpass.Text);
                        if (validLogin == true)
                        {
                            Cargar mainMenu = new Cargar();
                            mainMenu.Show();
                            Hide();
                        }
                        else
                        {
                            msgError("Nombre de usuario o contraseña incorrectos");

                            txtuser.Focus();
                        }
                    }
                    else msgError("Ingresa tu Contraseña.");
                }
                else msgError("Porfavor ingresa tu usuario.");
            }
        }
    }
}
