﻿using Dominio;
using System;
using System.Windows.Forms;



namespace Unitec.Admin
{
    public partial class Persona : Form
    {
        public Persona()
        {
            InitializeComponent();
        }

        UserModel objeto = new UserModel();
        private string idProducto = null;
        private string idProductoE = null;

        private string retornaI = null;
        private string retornaE = null;
        private string idTarjeton = null;
        private string idTarjetonE = null;

        private bool Editar = false;
        public bool repetir = true;
        public bool repetir1 = true;
        void Limpiar()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox1.Text = string.Empty;

            Editar = false;
            idProducto = null;
            idTarjeton = null;

            dateTimePicker1.Text = "2020-01-20";
            dateTimePicker2.Text = "2020-05-17";

        }
        void LimpiarEl()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox1.Text = string.Empty;

            dateTimePicker1.Text = "2020-01-20";
            dateTimePicker2.Text = "2020-05-17";
        }



        private void MostrarTablas()
        {
            UserModel objeto = new UserModel();
            dataGridView1.DataSource = objeto.MostrarTablas();
            textBox1.Focus();
        }

        public static void SoloLetras(KeyPressEventArgs v)
        {
            if (Char.IsLetter(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true; MessageBox.Show("Solo Letras");
            }
        }
        public static void SoloNumeros(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;
                MessageBox.Show("Solo Numeros");
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty && textBox6.Text != string.Empty && textBox5.Text != string.Empty)
            {


                if (Editar == false)
                {
                    //INSERTAR
                    //Nombre, ApellidoP, ApellidoM, P_Id_Rol, P_Id_Tarjeron, P_Id_N_Cuenta, Placas, Convert.ToDateTime(I_V), Convert.ToDateTime(F_V)

                    if (comboBox1.Text == "Estudiante")
                    {
                        string retorna = objeto.InsertarPer(textBox1.Text, textBox2.Text, textBox3.Text, "1", textBox4.Text, textBox5.Text, textBox6.Text, dateTimePicker1.Text, dateTimePicker2.Text, retornaI);

                        if (retorna == "Si")
                        {
                            MessageBox.Show("Se inserto correctamente");
                            MostrarTablas();
                            repetir = false;
                        }
                        if (retorna == "No")
                        {
                            MessageBox.Show("El tarjeton o numero de cuenta no estan disponibles");

                        }

                    }


                    if (comboBox1.Text == "Docente")
                    {

                        string retorna = objeto.InsertarPer(textBox1.Text, textBox2.Text, textBox3.Text, "2", textBox4.Text, textBox5.Text, textBox6.Text, dateTimePicker1.Text, dateTimePicker2.Text, retornaI);
                        if (retorna == "Si")
                        {
                            MessageBox.Show("Se inserto correctamente");
                            MostrarTablas();
                            repetir = false;
                        }
                        if (retorna == "No")
                        {
                            MessageBox.Show("El tarjeton o numero de cuenta no estan disponibles");

                        }


                    }





                }


                //EDITAR

                if (Editar == true)
                {

                    try
                    {


                        if (comboBox1.Text == "Estudiante")
                        {
                            string retorna = objeto.EditarPer(Convert.ToInt32(idProducto), textBox1.Text, textBox2.Text, textBox3.Text, "1", textBox4.Text, textBox5.Text, textBox6.Text, dateTimePicker1.Text, dateTimePicker2.Text, idTarjeton, retornaE);
                            if (retorna == "Si")
                            {
                                MessageBox.Show("Se Actualizó correctamente");
                                MostrarTablas();
                                repetir1 = false;
                            }
                            if (retorna == "No")
                            {
                                MessageBox.Show("El tarjeton o numero de cuenta no estan disponibles");

                            }

                        }

                        if (comboBox1.Text == "Docente")
                        {

                            string retorna = objeto.EditarPer(Convert.ToInt32(idProducto), textBox1.Text, textBox2.Text, textBox3.Text, "2", textBox4.Text, textBox5.Text, textBox6.Text, dateTimePicker1.Text, dateTimePicker2.Text, idTarjeton, retornaE);
                            if (retorna == "Si")
                            {
                                MessageBox.Show("Se Actualizó correctamente");
                                MostrarTablas();
                                repetir1 = false;
                            }
                            if (retorna == "No")
                            {
                                MessageBox.Show("El tarjeton o numero de cuenta no estan disponibles");

                            }
                        }



                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("No se pudo editar los datos por: " + ex);

                    }

                }
            }
        }



        private void Persona_Load(object sender, EventArgs e)
        {
            MostrarTablas();
            textBox1.MaxLength = 30;
            textBox2.MaxLength = 30;
            textBox3.MaxLength = 30;
            textBox4.MaxLength = 3;
            textBox5.MaxLength = 8;
            textBox6.MaxLength = 7;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloLetras(e);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloLetras(e);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloLetras(e);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Limpiar();

                Editar = true;

                textBox1.Text = dataGridView1.CurrentRow.Cells["Nombre"].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells["Apellido_Paterno"].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells["Apellido_Materno"].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells["Rol"].Value.ToString();
                textBox5.Text = dataGridView1.CurrentRow.Cells["N_Cuenta"].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells["Tarjeton"].Value.ToString();
                textBox6.Text = dataGridView1.CurrentRow.Cells["Placas"].Value.ToString();

                dateTimePicker1.Text = dataGridView1.CurrentRow.Cells["Inicio_Vigencia"].Value.ToString();
                dateTimePicker2.Text = dataGridView1.CurrentRow.Cells["Vigencia"].Value.ToString();


                idProducto = dataGridView1.CurrentRow.Cells["Id"].Value.ToString();
                idTarjeton = dataGridView1.CurrentRow.Cells["Tarjeton"].Value.ToString();

                textBox1.Focus();
            }
            else
                MessageBox.Show("Seleccione una fila por favor");
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                LimpiarEl();
                idProductoE = dataGridView1.CurrentRow.Cells["Id"].Value.ToString();
                idTarjetonE = dataGridView1.CurrentRow.Cells["Tarjeton"].Value.ToString();
                objeto.Eliminar(idProductoE, idTarjetonE);

                MostrarTablas();
                MessageBox.Show("Eliminado correctamente");


            }
            else
                MessageBox.Show("Seleccione una fila por favor");
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            textBox6.Text = textBox6.Text.ToUpper();
        }
    }
}
