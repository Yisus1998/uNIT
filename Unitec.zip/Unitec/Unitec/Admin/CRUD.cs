﻿using Dominio;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Unitec.Admin
{
    public partial class CRUD : Form
    {
        public CRUD()
        {
            InitializeComponent();
        }
        private string idProducto = null;
        private string idProductoE = null;
        private bool Editar = false;
        public bool repetir = true;
        public bool repetir1 = true;
        UserModel objeto = new UserModel();

        void Limpiar()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();

            textBox1.Focus();
            Editar = false;
            idProducto = null;
        }
        void LimpiarEl()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();



        }



        private void MostrarUS()
        {
            UserModel objeto = new UserModel();
            dataGridView1.DataSource = objeto.MostrarUS();
            textBox1.Focus();
        }

        private Boolean email_bien_escrito(String email)
        {
            String expresion;
            expresion = "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
            if (Regex.IsMatch(email, expresion))
            {
                if (Regex.Replace(email, expresion, String.Empty).Length == 0)
                {
                    return true;
                }
                else
                {

                    return false;
                }
            }
            else
            {
                MessageBox.Show("Correo no valido");
                return false;
            }
        }
        public static void SoloLetras(KeyPressEventArgs v)
        {
            if (Char.IsLetter(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true; MessageBox.Show("Solo Letras");
            }
        }
        public static void SoloNumeros(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;
                MessageBox.Show("Solo Numeros");
            }
        }
        public static void NumerosDecimales(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (v.KeyChar.ToString().Equals("."))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;
                MessageBox.Show("Solo numeros o numeros con punto decimal");
            }
        }



        private void CRUD_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
            MostrarUS();
            textBox1.MaxLength = 15;
            textBox2.MaxLength = 30;

        }

        private void Guardar_Click(object sender, EventArgs e)
        {


            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty && textBox3.Text != string.Empty && textBox4.Text != string.Empty && email_bien_escrito(textBox6.Text))
            {


                if (Editar == false)
                {
                    //INSERTAR
                    try
                    {

                        objeto.InsertarPRod(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, comboBox2.Text, textBox6.Text);
                        //MessageBox.Show("Se inserto correctamente");
                        MostrarUS();
                        repetir = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("No se pudo editar los datos por: " + ex);

                    }


                }


                //EDITAR

                if (Editar == true)
                {

                    try
                    {

                        objeto.EditarProd(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, comboBox2.Text, textBox6.Text, idProducto);
                        MessageBox.Show("Se edito correctamente");
                        MostrarUS();
                        repetir1 = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("No se pudo editar los datos por: " + ex);

                    }

                }
            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Limpiar();

                Editar = true;

                textBox1.Text = dataGridView1.CurrentRow.Cells["USUARIO"].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells["CONTRASEÑA"].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells["NOMBRE"].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells["APELLIDOS"].Value.ToString();
                textBox6.Text = dataGridView1.CurrentRow.Cells["EMAIL"].Value.ToString();
                comboBox2.Text = dataGridView1.CurrentRow.Cells["ROL"].Value.ToString();

                idProducto = dataGridView1.CurrentRow.Cells["ID"].Value.ToString();
                textBox1.Focus();
            }
            else
                MessageBox.Show("seleccione una fila por favor");
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {


            if (dataGridView1.SelectedRows.Count > 0)
            {
                LimpiarEl();
                idProductoE = dataGridView1.CurrentRow.Cells["ID"].Value.ToString();
                objeto.EliminarPRod(idProductoE);
                MostrarUS();
                MessageBox.Show("Eliminado correctamente");


            }
            else
                MessageBox.Show("Seleccione una fila por favor");


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloLetras(e);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloLetras(e);
        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            if (email_bien_escrito(textBox6.Text))
            {

            }
            else
            {

                textBox6.SelectAll();

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

