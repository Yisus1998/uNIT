﻿using System;
using System.Windows.Forms;

namespace Unitec
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            NewMethod();
        }

        private static void NewMethod()
        {
            Application.Run(new LoginForm());
        }
    }
}
