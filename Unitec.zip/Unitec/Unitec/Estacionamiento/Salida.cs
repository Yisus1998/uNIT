﻿using Common.Cache;
using Dominio;
using System;
using System.Windows.Forms;

namespace Unitec.Estacionamiento
{
    public partial class Salida : Form
    {
        public Salida()
        {
            InitializeComponent();

        }

        public int IdUser = UserLoginCache.IdUser;

        public static void SoloNumeros(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;

            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuDatepicker1_onValueChanged(object sender, EventArgs e)
        {

        }

        private void Salida_Load(object sender, EventArgs e)
        {
            bunifuMetroTextbox1.Focus();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton1_Click_1(object sender, EventArgs e)
        {

            UserModel objeto1 = new UserModel();

            if (bunifuMetroTextbox1.Text != string.Empty)
            {
                var validLogin = objeto1.Salida(bunifuMetroTextbox1.Text, DateTime.Now.ToString("HH:mm:ss"), "2", DateTime.Now.ToLongDateString(), IdUser);

                if (validLogin == true)
                {
                    MessageBox.Show("Se inserto correctamente");
                    bunifuMetroTextbox1.Text = string.Empty;
                    bunifuMetroTextbox1.Focus();
                }
                else
                {
                    MessageBox.Show("No se encontro Tarjeton");
                    bunifuMetroTextbox1.Text = string.Empty;
                    bunifuMetroTextbox1.Focus();

                }


            }
            else
            {
                // MessageBox.Show("Campo Vacio");
                bunifuMetroTextbox1.Focus();
            }



        }

        private void bunifuMetroTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMetroTextbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            VisitaS visita = new VisitaS();
            visita.Show();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {

        }
    }
}
