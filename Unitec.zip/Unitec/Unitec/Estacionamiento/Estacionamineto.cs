﻿using Common.Cache;
using Dominio;
using System;
using System.Windows.Forms;


namespace Unitec.Estacionamiento
{
    public partial class Estacionamineto : Form
    {

        
        private void Dashboard()
        {
            Dash neg = new Dash();
            EstaCache obj = new EstaCache();
            neg.Dashboard(obj, DateTime.Now.ToLongDateString());
            neg.Dashboard1(obj, DateTime.Now.ToLongDateString());
            neg.Dashboard2(obj, DateTime.Now.ToLongDateString());
            neg.Visitas(DateTime.Now.ToLongDateString());
            neg.Registro(DateTime.Now.ToLongDateString());
            //RECUPERAMOS DATOS DE LA ENTIDAD PARA CARGAR LOS DATOS DEL DASHBOARD
            chart2.Series[0].Points.DataBindXY(obj.Autos_H1,obj.Autos_H_cant1);
            Visitas.Series[0].Points.DataBindXY(obj.Autos_Vi1, obj.Autos_Vi_cant1);
            chart3.Series[0].Points.DataBindXY(obj.Autos_Vi_G1, obj.Autos_Vi__G_cant1);
         
            label2.Text =Convert.ToString(Registros.Tot_autos+Registros.Tot_autos_v);
            label4.Text =Convert.ToString(Registros.Tot_autos_sa+Registros.Tot_autos_sa_v);
        }

     
        public Estacionamineto()
        {
            InitializeComponent();
         

        }



        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void Estacionamineto_Load(object sender, EventArgs e)
        {
         
             Dashboard();
         
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click_1(object sender, EventArgs e)
        {

        }

        private void iconButton2_Click(object sender, EventArgs e)
        {

        }

        private void chart3_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click_2(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void iconPictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
