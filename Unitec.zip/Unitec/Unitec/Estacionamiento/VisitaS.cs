﻿using Common.Cache;
using Dominio;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Unitec.Estacionamiento
{
    public partial class VisitaS : Form
    {
        public VisitaS()
        {
            InitializeComponent();
            textBox1.Focus();
            textBox1.MaxLength = 7;
        }

        public int IdUser = UserLoginCache.IdUser;

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void iconButton1_Click(object sender, EventArgs e)
        {

            textBox1.Text = textBox1.Text.ToUpper();

            UserModel objeto1 = new UserModel();
            // objeto1.VisitSa(textBox1.Text, DateTime.Now.ToString("hh:mm"));



            if (textBox1.Text != string.Empty)
            {
                textBox1.Text = textBox1.Text.ToUpper();
                var validLogin = objeto1.VisitSa(textBox1.Text, DateTime.Now.ToString("HH:mm:ss"), IdUser, "2");
                Registros.Tot_autos_sa=0;
                Registros.Tot_autos_sa_v=0;



                if (validLogin == true)
                {

                    MessageBox.Show("El vehiculo ha Salio");
                    Close();

                }
                else
                {
                    MessageBox.Show("No se encontro el vehiculo");
                    textBox1.Focus();

                }


            }
            else
            {
                // MessageBox.Show("Campo Vacio");
                textBox1.Focus();
            }

        }

        private void VisitaS_Load(object sender, EventArgs e)
        {

        }

        private void maximize_Click(object sender, EventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void VisitaS_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}
