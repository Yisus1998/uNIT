﻿using Common.Cache;
using Dominio;
using System;
using System.Windows.Forms;


namespace Unitec.Estacionamiento
{
    public partial class Entrada : Form
    {
        public Entrada()
        {
            InitializeComponent();
        }


        public int IdUser = UserLoginCache.IdUser;


        public static void SoloNumeros(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;

            }
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {

        }

        private void iconButton3_Click(object sender, EventArgs e)
        {

        }

        private void iconButton2_Click(object sender, EventArgs e)
        {

        }

        private void iconButton3_Click_1(object sender, EventArgs e)
        {
            VisitaE visita = new VisitaE();
            visita.Show();
        }



        private void bunifuMetroTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void bunifuMetroTextbox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            SoloNumeros(e);
        }

        private void Entrada_Load(object sender, EventArgs e)
        {
            bunifuMetroTextbox1.Focus();
        }

        private void iconButton2_Click_1(object sender, EventArgs e)
        {

        }

        private void iconButton1_Click_1(object sender, EventArgs e)
        {
            UserModel objeto1 = new UserModel();
            var valida = objeto1.Valida(bunifuMetroTextbox1.Text);


            if (bunifuMetroTextbox1.Text != string.Empty)
            {
                if (valida == true)
                {
                    MessageBox.Show("Se acaba de ingresar ese tarjeton");
                    bunifuMetroTextbox1.Text = string.Empty;
                    bunifuMetroTextbox1.Focus();
                }
                if (valida == false)
                {

                    var validLogin = objeto1.InsertarAuto(bunifuMetroTextbox1.Text, DateTime.Now.ToString("HH:mm:ss"), DateTime.Now.ToLongDateString(), "1", IdUser);

                    if (validLogin == true)
                    {
                        MessageBox.Show("Se inserto correctamente");
                        bunifuMetroTextbox1.Text = string.Empty;
                        bunifuMetroTextbox1.Focus();
                    }
                    else
                    {
                        MessageBox.Show("No se encontro Tarjeton");
                        bunifuMetroTextbox1.Text = string.Empty;
                        bunifuMetroTextbox1.Focus();

                    }
                }


            }
            else
            {
                /// MessageBox.Show("Campo Vacio");
                bunifuMetroTextbox1.Focus();
            }


        }

        private void iconButton3_Click_2(object sender, EventArgs e)
        {
            VisitaE visita = new VisitaE();
            visita.Show();
        }

        private void bunifuMetroTextbox1_OnValueChanged_1(object sender, EventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Entrada_Load_1(object sender, EventArgs e)
        {
            bunifuMetroTextbox1.Focus();
        }
    }
}



