﻿using Common.Cache;
using Dominio;
using System;
using System.Windows.Forms;

namespace Unitec.Estacionamiento
{
    public partial class DataDash : Form
    {
        public DataDash()
        {
            InitializeComponent();
        }

        private void Dashboard()
        {
            Dash neg = new Dash();
            EstaCache obj = new EstaCache();
            neg.Dashboard(obj, dateTimePicker1.Text);
            neg.Dashboard1(obj, dateTimePicker1.Text);
            neg.Dashboard2(obj, dateTimePicker1.Text);
            neg.Registro(dateTimePicker1.Text);
            neg.Visitas(dateTimePicker1.Text);
            //RECUPERAMOS DATOS DE LA ENTIDAD PARA CARGAR LOS DATOS DEL DASHBOARD
            chart2.Series[0].Points.DataBindXY(obj.Autos_H1, obj.Autos_H_cant1);
            Visitas.Series[0].Points.DataBindXY(obj.Autos_Vi1, obj.Autos_Vi_cant1);
            chart3.Series[0].Points.DataBindXY(obj.Autos_Vi_G1, obj.Autos_Vi__G_cant1);

            label2.Text = Convert.ToString(Registros.Tot_autos_sa + Registros.Tot_autos_sa_v);
        }

        private void DataDash_Load(object sender, EventArgs e)
        {
            Dashboard();
        }

        private void chart3_Click(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            Dashboard();
        }
    }
}
