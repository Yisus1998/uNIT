﻿using Common.Cache;
using Dominio;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Unitec.Estacionamiento
{
    public partial class VisitaE : Form
    {
        public VisitaE()
        {
            InitializeComponent();
            textBox2.Enabled = false;
            textBox1.Focus();
            textBox1.MaxLength = 7;

        }

        public int IdUser = UserLoginCache.IdUser;


        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Otro")
            {
                textBox2.Enabled = true;
                textBox1.Text = textBox1.Text.ToUpper();
                textBox2.Focus();

            }
            if (comboBox1.Text != "Otro")
            {
                textBox2.Enabled = false;
                textBox1.Text = textBox1.Text.ToUpper();
            }

        }

        private void VisitaE_Load(object sender, EventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            UserModel objeto1 = new UserModel();
            var valida = objeto1.Valida1(textBox1.Text);

            if (textBox1.Text != string.Empty && comboBox1.Text != string.Empty)
            {
                if (comboBox1.Text != "Otro")
                {

                    textBox1.Text = textBox1.Text.ToUpper();
                    if (valida == true)
                    {
                        MessageBox.Show("Actualmente se encuentra en el estacionamiento");
                        textBox1.Text = string.Empty;
                    }
                    if (valida == false)
                    {

                        objeto1.VisitEn(textBox1.Text, DateTime.Now.ToString("HH:mm:ss"), comboBox1.Text, DateTime.Now.ToLongDateString(), IdUser, "1");
                        MessageBox.Show("Se registro el vehiculo");
                        Close();


                    }


                }

                if (comboBox1.Text == "Otro" && textBox2.Text != string.Empty)
                {
                    textBox1.Text = textBox1.Text.ToUpper();
                    if (valida == true)
                    {
                        MessageBox.Show("Actualmente se encuentra en el estacionamiento");
                        textBox1.Text = string.Empty;
                    }
                    if (valida == false)
                    {

                        objeto1.VisitEn(textBox1.Text, DateTime.Now.ToString("HH:mm:ss"), textBox2.Text, DateTime.Now.ToLongDateString(), IdUser, "1");
                        Close();
                        MessageBox.Show("Se registro el vehiculo");

                    }


                }
            }
            else
            {
                MessageBox.Show("Dejo un campo vacio");
                textBox1.Focus();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void VisitaE_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void VisitaE_Leave(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void VisitaE_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}
